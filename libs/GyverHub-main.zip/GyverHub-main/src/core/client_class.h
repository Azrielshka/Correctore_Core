#pragma once

namespace gh {
class Client;
}