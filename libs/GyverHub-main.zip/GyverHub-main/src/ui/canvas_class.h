#pragma once
namespace gh {

class Canvas;

}  // namespace gh